etlinefont-bower
================


Elegant Themes 100 Line Icons
-----------------------------

A GPL-licensed icon font by [Elegant Themes](http://www.elegantthemes.com/).

Packaged as a bower component by [Paul Prince](http://littlebluetech.com/).


### Upstream ###


#### AI/SVG/PNG Release ####

  * [Release Announcement](http://www.elegantthemes.com/blog/freebie-of-the-week/free-line-style-icons)
  * [Download Archive](http://www.elegantthemes.com/icons/line-icons.zip)


#### Font File Release ####

  * [Release Announcement](http://www.elegantthemes.com/blog/resources/how-to-use-and-embed-an-icon-font-on-your-website)
  * [Download Archive](http://www.elegantthemes.com/icons/et-line-font.zip)


### Licensing ###

The blog post / release announcement states that "As always, these icons are
completely free to use, and have been released under the GPL."

They hyper-link the word "GPL" to it to
[GPLv3](http://www.gnu.org/licenses/gpl.html).
