﻿
var enviarAjax = function (peticionTipo, parametros) {

    $.ajax({
        type : peticionTipo,
        data: parametros,
        url : 
    })
}